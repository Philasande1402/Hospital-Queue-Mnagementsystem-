/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.Date;
import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entities.Clerk;

/**
 *
 * @author Mmaga
 */
@Local
public interface ClerkFacadeLocal {

    Clerk findByEmployeeId(String employeeId);

    Clerk login(String username, String password);

    List<Clerk> findActiveOnly();

    Clerk save(Clerk clerk);

    Clerk update(Clerk clerk);

    void remove(Clerk clerk);

    Clerk findById(Long id);

    List<Clerk> findAll();

    void edit(Clerk clerk);

    int count();

    List<Clerk> findPatientsWithinDateRange(Date from, Date to);

    Long cntAllMalePatients();

    Long cntAllFemalePatients();

}
