/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Mmaga
 */
@Entity
@Table(name = "Clerks")
public class Clerk implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long clerkId;
    private String fullName;
    private String username;
    private String password;
    private String role; // e.g., Registration, QueueMgr
    private String email;
    private String phoneNumber;
    
    @Temporal(TemporalType.DATE)
    private Date lastLogin;
    
    @Enumerated(EnumType.STRING)
    private AccountStatus status;

    @OneToMany(cascade = CascadeType.ALL)
    private List<QueueEntry> registeredQueueEntries;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Patient> registeredPatients;

    public Clerk() {
    }

    public Clerk(Long clerkId, String fullName, String username, String password, String role, String email, String phoneNumber, AccountStatus status, List<QueueEntry> registeredQueueEntries, List<Patient> registeredPatients) {
        this.clerkId = clerkId;
        this.fullName = fullName;
        this.username = username;
        this.password = password;
        this.role = role;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.status = status;
        this.registeredQueueEntries = registeredQueueEntries;
        this.registeredPatients = registeredPatients;
    }

    

    public Long getClerkId() {
        return clerkId;
    }

    public void setClerkId(Long clerkId) {
        this.clerkId = clerkId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public AccountStatus getStatus() {
        return status;
    }

    public void setStatus(AccountStatus status) {
        this.status = status;
    }

    public List<QueueEntry> getRegisteredQueueEntries() {
        return registeredQueueEntries;
    }

    public void setRegisteredQueueEntries(List<QueueEntry> registeredQueueEntries) {
        this.registeredQueueEntries = registeredQueueEntries;
    }

    public List<Patient> getRegisteredPatients() {
        return registeredPatients;
    }

    public void setRegisteredPatients(List<Patient> registeredPatients) {
        this.registeredPatients = registeredPatients;
    }

    public Date getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(Date lastLogin) {
        this.lastLogin = lastLogin;
    }

    
}
