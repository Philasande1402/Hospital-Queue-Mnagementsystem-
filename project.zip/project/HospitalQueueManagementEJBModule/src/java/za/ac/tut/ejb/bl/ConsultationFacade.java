/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import za.ac.tut.entities.Consultation;

/**
 *
 * @author Mmaga
 */
@Stateless
public class ConsultationFacade extends AbstractFacade<Consultation> implements ConsultationFacadeLocal {

    @PersistenceContext(unitName = "HospitalQueueManagementEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ConsultationFacade() {
        super(Consultation.class);
    }

    @Override
    public Consultation findById(Long id) {
         try {
            return em.find(Consultation.class, id);
        } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
    }

    @Override
    public List<Consultation> findByPatientId(Long patientId) {
        try {
            TypedQuery<Consultation> query = em.createQuery(
                "SELECT c FROM Consultation c WHERE c.patient.id = :patientId ORDER BY c.consultationDate DESC", Consultation.class);
            query.setParameter("patientId", patientId);
            return query.getResultList();
        } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
    }

    @Override
    public Consultation save(Consultation consultation) {
        try {
            em.getTransaction().begin();
            if (consultation.getId() == null) {
                em.persist(consultation);
            } else {
                consultation = em.merge(consultation);
            }
            em.getTransaction().commit();
            return consultation;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw e;
        } 
    }
    
}
