/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.Date;
import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entities.MedicalRecord;
import za.ac.tut.entities.Patient;

/**
 *
 * @author Mmaga
 */
@Local
public interface PatientFacadeLocal {
    
    void edit(Patient patient);

    Patient findById(Long id);
    
    List<MedicalRecord> getPatientMedicalHistory(Long patientId);
    
    Patient save(Patient patient);
    
    List<Patient> findAllPendingPatients();
    
    List<Patient> findAll();
    
    void remove(Patient patient);
    
    long countPatients();
    
    List<Patient> findAllPatients();
    
    public List<Patient> findPatientsWithinDateRange(Date start, Date end);
}
