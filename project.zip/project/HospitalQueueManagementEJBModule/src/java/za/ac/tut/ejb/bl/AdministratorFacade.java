/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import za.ac.tut.entities.Administrator;
import za.ac.tut.entities.Clerk;

/**
 *
 * @author Mmaga
 */
@Stateless
public class AdministratorFacade extends AbstractFacade<Administrator> implements AdministratorFacadeLocal {

    @PersistenceContext(unitName = "HospitalQueueManagementEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AdministratorFacade() {
        super(Administrator.class);
    }

    @Override
    public Administrator findByEmployeeId(String employeeId) {
        try {
            TypedQuery<Administrator> query = em.createQuery(
                "SELECT a FROM Administrator a WHERE a.employeeId = :employeeId", 
                Administrator.class);
            query.setParameter("employeeId", employeeId);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Administrator> findActiveOnly() {
        TypedQuery<Administrator> query = em.createQuery(
            "SELECT a FROM Administrator a WHERE a.active = true", 
            Administrator.class);
        return query.getResultList();
    }

    @Override
    public Administrator login(String username, String password) {
        try {
            TypedQuery<Administrator> query = em.createQuery(
                "SELECT a FROM Administrator a WHERE a.username = :username AND a.password = :password", 
                Administrator.class);
            query.setParameter("username", username);
            query.setParameter("password", password);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    
}
