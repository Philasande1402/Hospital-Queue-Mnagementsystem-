package za.ac.tut.ejb.bl;

import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import za.ac.tut.entities.QueueEntry;

@Stateless
public class QueueEntryFacade extends AbstractFacade<QueueEntry> implements QueueEntryFacadeLocal {

    @PersistenceContext(unitName = "HospitalQueueManagementEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public QueueEntryFacade() {
        super(QueueEntry.class);
    }

    @Override
    public QueueEntry findById(Long id) {
        return em.find(QueueEntry.class, id);
    }

    @Override
    public QueueEntry save(QueueEntry queueEntry) {
        if (queueEntry.getId() == null) {
            em.persist(queueEntry);
        } else {
            queueEntry = em.merge(queueEntry);
        }
        return queueEntry;
    }

    @Override
    public QueueEntry getNextPatientForDoctor(Long doctorId) {
        TypedQuery<QueueEntry> query = em.createQuery(
                "SELECT q FROM QueueEntry q WHERE q.assignedDoctor.id = :doctorId AND q.status <> za.ac.tut.entities.QueueEntry.Status.COMPLETED ORDER BY q.priority DESC, q.registrationTime",
                QueueEntry.class
        );
        query.setParameter("doctorId", doctorId);
        query.setMaxResults(1);
        List<QueueEntry> results = query.getResultList();
        return results.isEmpty() ? null : results.get(0);
    }

    @Override
    public List<QueueEntry> getQueueForDoctor(Long doctorId) {
        TypedQuery<QueueEntry> query = em.createQuery(
                "SELECT q FROM QueueEntry q WHERE q.assignedDoctor.id = :doctorId AND q.status <> za.ac.tut.entities.QueueEntry.Status.COMPLETED ORDER BY q.priority DESC, q.registrationTime",
                QueueEntry.class
        );
        query.setParameter("doctorId", doctorId);
        return query.getResultList();
    }

    @Override
    public void updateStatus(Long queueEntryId, QueueEntry.Status status) {
        QueueEntry entry = em.find(QueueEntry.class, queueEntryId);
        if (entry != null) {
            entry.setStatus(status);
            em.merge(entry);
        }
    }

    @Override
    public int getNextQueueNumberForDoctor(Long doctorId) {
        TypedQuery<Integer> query = em.createQuery(
                "SELECT MAX(q.queueNumber) FROM QueueEntry q WHERE q.assignedDoctor.id = :doctorId",
                Integer.class
        );
        query.setParameter("doctorId", doctorId);
        Integer maxQueueNumber = query.getSingleResult();
        return (maxQueueNumber == null) ? 1 : maxQueueNumber + 1;
    }

    @Override
    public QueueEntry findByPatientId(Long patientId) {
        try {
            TypedQuery<QueueEntry> query = em.createQuery(
                    "SELECT q FROM QueueEntry q WHERE q.patient.id = :patientId", QueueEntry.class);
            query.setParameter("patientId", patientId);
            List<QueueEntry> results = query.getResultList();
            return (results != null && !results.isEmpty()) ? results.get(0) : null; // Assuming you only need the first entry
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public QueueEntry findNextWaitingPatient() {
        try {
            TypedQuery<QueueEntry> query = em.createQuery(
                    "SELECT q FROM QueueEntry q WHERE q.status = :status ORDER BY q.registrationTime ASC",
                    QueueEntry.class
            );
            query.setParameter("status", QueueEntry.Status.WAITING);
            query.setMaxResults(1);
            List<QueueEntry> results = query.getResultList();
            return results.isEmpty() ? null : results.get(0);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<QueueEntry> findAll() {
        return em.createQuery("SELECT q FROM QueueEntry q", QueueEntry.class).getResultList();
    }

    @Override
    public QueueEntry update(QueueEntry queueEntry) {
        return em.merge(queueEntry);
    }

    @Override
    public void remove(QueueEntry queueEntry) {
        QueueEntry q = em.merge(queueEntry);
        em.remove(q);
    }

    @Override
    public QueueEntry findByQueueNumber(Long queueNumber) {
        try {
            return em.createQuery(
                    "SELECT q FROM QueueEntry q WHERE q.queueNumber = :queueNumber", QueueEntry.class)
                    .setParameter("queueNumber", queueNumber)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }
    
    @Override
    public int count() {
        return ((Long) em.createQuery("SELECT COUNT(q) FROM QueueEntry q").getSingleResult()).intValue();
    }

    @Override
    public int countWaitingEntries() {
         return ((Long) em.createQuery("SELECT COUNT(q) FROM QueueEntry q WHERE q.status = :status")
                .setParameter("status", QueueEntry.Status.WAITING) // Update with correct status
                .getSingleResult()).intValue();
    }

    @Override
    public int countByPriority(QueueEntry.Priority priority) {
        return ((Long) em.createQuery("SELECT COUNT(q) FROM QueueEntry q WHERE q.priority = :priority")
                .setParameter("priority", priority) // Use the passed priority value
                .getSingleResult()).intValue();
    }
    
    @Override
    public List<QueueEntry> getReportsByDoctorAndDate(Long doctorId, Date startDate) {
        Query query = em.createQuery("SELECT q FROM QueueEntry q WHERE q.assignedDoctor.id = :doctorId AND q.registrationTime >= :startDate");
        query.setParameter("doctorId", doctorId);
        query.setParameter("startDate", startDate);
        return query.getResultList();
    }

    public List<QueueEntry> getReportsByDoctorAndDateRange(Long doctorId, Date startDate, Date endDate) {
    Query query = em.createQuery("SELECT q FROM QueueEntry q WHERE q.assignedDoctor.id = :doctorId AND q.registrationTime >= :startDate AND q.registrationTime <= :endDate");
    query.setParameter("doctorId", doctorId);
    query.setParameter("startDate", startDate);
    query.setParameter("endDate", endDate);
    return query.getResultList();
}

}
