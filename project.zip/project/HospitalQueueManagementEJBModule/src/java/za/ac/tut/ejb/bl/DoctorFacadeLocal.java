/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.QueueEntry;

/**
 *
 * @author Mmaga
 */
@Local
public interface DoctorFacadeLocal {

    
    Doctor findById(Long id);
    
    Doctor findByUsername(String username);
    
    Doctor login(String username , String password);
    
    
    Doctor save(Doctor doctor);
   
    List<Doctor> findAll();
    
    void remove(Doctor doctor);
    
    void edit(Doctor doctor);
    
    int count();
}
