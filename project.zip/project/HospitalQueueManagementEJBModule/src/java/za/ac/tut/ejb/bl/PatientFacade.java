/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import za.ac.tut.entities.MedicalRecord;
import za.ac.tut.entities.Patient;

/**
 *
 * @author Mmaga
 */
@Stateless
public class PatientFacade extends AbstractFacade<Patient> implements PatientFacadeLocal {

    @PersistenceContext(unitName = "HospitalQueueManagementEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PatientFacade() {
        super(Patient.class);
    }

    @Override
    public Patient findById(Long id) {
        try {
            return em.find(Patient.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void edit(Patient patient) {
        em.merge(patient); // updates the existing patient record
    }

    @Override
    public List<MedicalRecord> getPatientMedicalHistory(Long patientId) {
        try {
            TypedQuery<MedicalRecord> query = em.createQuery(
                    "SELECT m FROM MedicalRecord m WHERE m.patient.id = :patientId ORDER BY m.recordDate DESC", MedicalRecord.class);
            query.setParameter("patientId", patientId);
            return query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Patient save(Patient patient) {
        try {
            if (patient.getId() == null) {
                em.persist(patient);
            } else {
                patient = em.merge(patient);
            }
            return patient;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public List<Patient> findAllPendingPatients() {
        try {
            TypedQuery<Patient> query = em.createQuery(
                    "SELECT DISTINCT c.patient FROM Consultation c WHERE c.status = :status ORDER BY c.createdAt ASC",
                    Patient.class);
            query.setParameter("status", "WAITING");
            return query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Patient> findAll() {
        return em.createQuery("SELECT p FROM Patient p", Patient.class).getResultList();
    }

    @Override
    public void remove(Patient patient) {
        em.remove(em.merge(patient));  // Ensure the entity is managed
    }

    @Override
    public long countPatients() {
        // Query the database to count the number of patients
        return em.createQuery("SELECT COUNT(p) FROM Patient p", Long.class).getSingleResult();
    }

    @Override
    public List<Patient> findPatientsWithinDateRange(Date start, Date end) {
        Query query = em.createQuery("SELECT p FROM Patient p WHERE p.dateOfBirth >= :startDate AND p.dateOfBirth <= :endDate ORDER BY p.dateOfBirth ASC");
        query.setParameter("startDate", start);
        query.setParameter("endDate", end);
        List<Patient> clerks = query.getResultList();
        return clerks;
    }
    
     @Override
    public List<Patient> findAllPatients() {
        return em.createQuery("SELECT p FROM Patient p", Patient.class)
                 .getResultList();
    }

}
