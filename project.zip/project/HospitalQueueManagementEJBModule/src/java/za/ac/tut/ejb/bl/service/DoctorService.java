/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package za.ac.tut.ejb.bl.service;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import za.ac.tut.ejb.bl.ConsultationFacadeLocal;
import za.ac.tut.ejb.bl.DoctorFacadeLocal;
import za.ac.tut.ejb.bl.MedicalRecordFacadeLocal;
import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.Consultation;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.MedicalRecord;
import za.ac.tut.entities.Patient;
import za.ac.tut.entities.QueueEntry;

/**
 *
 * @author Mmaga
 */
@Stateless
public class DoctorService {
     @EJB
    private DoctorFacadeLocal doctorFacade;
    
    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;
    
    @EJB
    private ConsultationFacadeLocal consultationFacade;
    
    @EJB
    private MedicalRecordFacadeLocal medicalRecordFacade;
    
    @EJB
    private PatientFacadeLocal patientFacade;
    
    public Doctor login(String username, String password) {
        Doctor doctor = doctorFacade.findByUsername(username);
        if (doctor != null && doctor.getPassword().equals(password)) {
            return doctor;
        }
        return null;
    }
    
    public List<QueueEntry> getQueueForDoctor(Long doctorId) {
        return queueEntryFacade.getQueueForDoctor(doctorId);
    }
    
    public QueueEntry getNextPatient(Long doctorId) {
        return queueEntryFacade.getNextPatientForDoctor(doctorId);
    }
    
    public MedicalRecord getPatientMedicalHistory(Long patientId) {
        return medicalRecordFacade.findByPatientId(patientId);
    }
    
    public void updatePatientStatus(Long queueEntryId, QueueEntry.Status status) {
        queueEntryFacade.updateStatus(queueEntryId, status);
    }
    
    public Consultation startConsultation(Long doctorId, Long patientId) {
        Doctor doctor = doctorFacade.findById(doctorId);
        QueueEntry queueEntry = queueEntryFacade.findById(patientId);
        
        if (doctor == null || queueEntry == null) {
            throw new IllegalArgumentException("Doctor or patient not found");
        }
        
        // Update queue status to IN_CONSULTATION
        queueEntry.setStatus(QueueEntry.Status.IN_CONSULTATION);
        queueEntryFacade.save(queueEntry);
        
        // Create a new consultation
        Consultation consultation = new Consultation();
        consultation.setDoctor(doctor);
        consultation.setPatient(queueEntry.getPatient());
        consultation.setConsultationDate(new Date());
        consultation.setCompleted(false);
        
        return consultationFacade.save(consultation);
    }
    
    public void completeConsultation(Long consultationId, String diagnosis, String notes, String prescriptions) {
        Consultation consultation = consultationFacade.findById(consultationId);
        if (consultation == null) {
            throw new IllegalArgumentException("Consultation not found");
        }
        
        // Update consultation
        consultation.setDiagnosis(diagnosis);
        consultation.setNotes(notes);
        consultation.setPrescriptions(prescriptions);
        consultation.setCompleted(true);
        consultationFacade.save(consultation);
        
        // Update patient queue status
        QueueEntry queueEntry = consultation.getPatient().getQueueEntry();
        if (queueEntry != null) {
            queueEntry.setStatus(QueueEntry.Status.COMPLETED);
            queueEntryFacade.save(queueEntry);
        }
        
        // Create medical record from consultation
        MedicalRecord record = new MedicalRecord();
        record.setPatient(consultation.getPatient());
        record.setDoctor(consultation.getDoctor());
        record.setRecordDate(new Date());
        record.setDiagnosis(diagnosis);
        record.setPrescriptions(prescriptions);
        record.setNotes(notes);
        medicalRecordFacade.save(record);
    }
    
    public MedicalRecord createMedicalRecord(Long doctorId, Long patientId, String diagnosis, 
                                             String treatment, String prescriptions, String notes) {
        Doctor doctor = doctorFacade.findById(doctorId);
        Patient patient = patientFacade.findById(patientId);
        
        if (doctor == null || patient == null) {
            throw new IllegalArgumentException("Doctor or patient not found");
        }
        
        MedicalRecord record = new MedicalRecord();
        record.setDoctor(doctor);
        record.setPatient(patient);
        record.setRecordDate(new Date());
        record.setDiagnosis(diagnosis);
        record.setPrescriptions(prescriptions);
        record.setNotes(notes);
        
        return medicalRecordFacade.save(record);
    }
}
