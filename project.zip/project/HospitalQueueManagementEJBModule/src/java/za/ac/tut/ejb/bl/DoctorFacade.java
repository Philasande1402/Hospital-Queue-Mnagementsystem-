/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.QueueEntry;

/**
 *
 * @author Mmaga
 */
@Stateless
public class DoctorFacade extends AbstractFacade<Doctor> implements DoctorFacadeLocal {

    @PersistenceContext(unitName = "HospitalQueueManagementEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DoctorFacade() {
        super(Doctor.class);
    }

    @Override
    public Doctor findById(Long id) {
        return em.find(Doctor.class, id);

    }

    @Override
    public Doctor findByUsername(String username) {
        try {
            TypedQuery<Doctor> query = em.createQuery(
                    "SELECT d FROM Doctor d WHERE d.username = :username", Doctor.class);
            query.setParameter("username", username);
            List<Doctor> results = query.getResultList();
            return results.isEmpty() ? null : results.get(0);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void remove(Doctor doctor) {
        em.remove(em.merge(doctor));
    }

    public void edit(Doctor doctor) {
        getEntityManager().merge(doctor);
    }

    @Override
    public Doctor save(Doctor doctor) {
        if (doctor.getId() == null) {
            em.persist(doctor);
        } else {
            doctor = em.merge(doctor);
        }
        return doctor;
    }

   public Doctor login(String username, String password) {
    try {
        // Check if doctor exists with the given username
        Query query = em.createQuery("SELECT d FROM Doctor d WHERE d.username = :username AND d.password = :password");
        query.setParameter("username", username);
        query.setParameter("password", password);
        Doctor doctor = (Doctor) query.getSingleResult();
        return doctor;
    } catch (NoResultException e) {
        return null;
    }
}


    @Override
    public List<Doctor> findAll() {
        // Fetch all doctors from the database
        TypedQuery<Doctor> query = em.createQuery("SELECT d FROM Doctor d", Doctor.class);
        return query.getResultList();
    }
    
     @Override
    public int count() {
        return ((Long) em.createQuery("SELECT COUNT(d) FROM Doctor d").getSingleResult()).intValue();
    }
}
