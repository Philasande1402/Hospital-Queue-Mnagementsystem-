/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import za.ac.tut.entities.MedicalRecord;

/**
 *
 * @author Mmaga
 */
@Stateless
public class MedicalRecordFacade extends AbstractFacade<MedicalRecord> implements MedicalRecordFacadeLocal {

    @PersistenceContext(unitName = "HospitalQueueManagementEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MedicalRecordFacade() {
        super(MedicalRecord.class);
    }

    @Override
    public MedicalRecord findById(Long id) {
        try {
            return em.find(MedicalRecord.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public MedicalRecord findByPatientId(Long patientId) {
        try {
            TypedQuery<MedicalRecord> query = em.createQuery(
                    "SELECT m FROM MedicalRecord m WHERE m.patient.id = :patientId ORDER BY m.recordDate DESC", MedicalRecord.class);
            query.setParameter("patientId", patientId);
            query.setMaxResults(1);  // Get only the most recent record
            return query.getResultList().isEmpty() ? null : query.getResultList().get(0);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public MedicalRecord save(MedicalRecord record) {
        try {
            if (record.getId() == null) {
                em.persist(record);  // Create a new record
            } else {
                record = em.merge(record);  // Update an existing record
            }
            return record;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;  // Throw exception to be handled by the container
        }
    }

}
