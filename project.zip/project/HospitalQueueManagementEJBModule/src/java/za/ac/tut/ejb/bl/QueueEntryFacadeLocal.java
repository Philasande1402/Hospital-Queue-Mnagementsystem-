package za.ac.tut.ejb.bl;

import java.util.Date;
import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entities.QueueEntry;

@Local
public interface QueueEntryFacadeLocal {

    QueueEntry findById(Long id);

    QueueEntry save(QueueEntry queueEntry);

    QueueEntry getNextPatientForDoctor(Long doctorId);

    List<QueueEntry> getQueueForDoctor(Long doctorId);

    void updateStatus(Long queueEntryId, QueueEntry.Status status);

    int getNextQueueNumberForDoctor(Long doctorId); // New method

    QueueEntry findByPatientId(Long patientId);

    public QueueEntry findNextWaitingPatient();

    QueueEntry update(QueueEntry queueEntry);

    List<QueueEntry> findAll();

    void remove(QueueEntry queueEntry);

    public QueueEntry findByQueueNumber(Long queueNumber);

    int count();

    int countWaitingEntries();

    int countByPriority(QueueEntry.Priority priority);

    List<QueueEntry> getReportsByDoctorAndDate(Long doctorId, Date startDate);

    List<QueueEntry> getReportsByDoctorAndDateRange(Long doctorId, Date startDate, Date endDate);
}
