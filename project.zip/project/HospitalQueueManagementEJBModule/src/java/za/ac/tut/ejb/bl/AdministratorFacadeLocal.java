/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entities.Administrator;


/**
 *
 * @author Mmaga
 */
@Local
public interface AdministratorFacadeLocal {

     Administrator findByEmployeeId(String employeeId);
     
     List<Administrator> findActiveOnly();
     
    Administrator login(String username, String password);
}
