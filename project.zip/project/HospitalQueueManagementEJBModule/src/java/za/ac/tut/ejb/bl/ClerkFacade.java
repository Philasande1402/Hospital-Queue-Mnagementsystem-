/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import za.ac.tut.entities.Clerk;

/**
 *
 * @author Mmaga
 */
@Stateless
public class ClerkFacade extends AbstractFacade<Clerk> implements ClerkFacadeLocal {

    @PersistenceContext(unitName = "HospitalQueueManagementEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ClerkFacade() {
        super(Clerk.class);
    }

    @Override
    public Clerk login(String username, String password) {
        try {
            TypedQuery<Clerk> query = em.createQuery(
                    "SELECT c FROM Clerk c WHERE c.username = :username AND c.password = :password ",
                    Clerk.class);
            query.setParameter("username", username);
            query.setParameter("password", password);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void edit(Clerk clerk) {
        em.merge(clerk);
    }

    @Override
    public Clerk findByEmployeeId(String employeeId) {
        try {
            TypedQuery<Clerk> query = em.createQuery(
                    "SELECT c FROM Clerk c WHERE c.employeeId = :employeeId",
                    Clerk.class);
            query.setParameter("employeeId", employeeId);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Clerk> findActiveOnly() {
        TypedQuery<Clerk> query = em.createQuery(
                "SELECT c FROM Clerk c WHERE c.active = true",
                Clerk.class);
        return query.getResultList();
    }

    @Override
    public Clerk save(Clerk clerk) {
        em.persist(clerk);
        return clerk;
    }

    @Override
    public Clerk update(Clerk clerk) {
        return em.merge(clerk);
    }

    @Override
    public void remove(Clerk clerk) {
        em.remove(em.merge(clerk));
    }

    @Override
    public Clerk findById(Long id) {
        return em.find(Clerk.class, id);
    }

    @Override
    public List<Clerk> findAll() {
        return em.createQuery("SELECT c FROM Clerk c", Clerk.class).getResultList();
    }

    @Override
    public int count() {
        return ((Long) em.createQuery("SELECT COUNT(c) FROM Clerk c").getSingleResult()).intValue();
    }
    
    
    
    @Override
    public List<Clerk> findPatientsWithinDateRange(Date from, Date to) {
         return em.createQuery("SELECT c FROM Clerk c WHERE c.patient.dateOfBirth BETWEEN :from AND :to", Clerk.class)
             .setParameter("from", from)
             .setParameter("to", to)
             .getResultList();
    }

    @Override
    public Long cntAllMalePatients() {
        return em.createQuery(
            "SELECT COUNT(c) FROM Clerk c WHERE c.gender = 'MALE'", Long.class).getSingleResult();
    }

    @Override
    public Long cntAllFemalePatients() {
        return em.createQuery(
            "SELECT COUNT(c) FROM Clerk c WHERE c.gender = 'FEMALE'", Long.class).getSingleResult();
    }
}
