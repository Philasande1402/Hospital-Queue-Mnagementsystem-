package za.ac.tut.entities;

public enum AccountStatus {
    ACTIVE,
    INACTIVE
}
