package za.ac.tut.web;

import za.ac.tut.ejb.bl.DoctorFacadeLocal;
import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.Patient;
import za.ac.tut.entities.QueueEntry;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import za.ac.tut.entities.QueueEntry.Priority;
import za.ac.tut.entities.QueueEntry.Status;

@WebServlet("/QueueMonitoringServlet")
public class QueueMonitoringServlet extends HttpServlet {

    @EJB
    private QueueEntryFacadeLocal queueFacade;

    @EJB
    private PatientFacadeLocal patientFacade;

    @EJB
    private DoctorFacadeLocal doctorFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.print("quueue mon do get ");
        String action = request.getParameter("action");

        if ("edit".equals(action)) {
            Long id = Long.parseLong(request.getParameter("id"));

            System.out.print(id);

            QueueEntry entry = queueFacade.findByQueueNumber(id);
            request.setAttribute("entry", entry);
            request.getRequestDispatcher("edit-queue.jsp").forward(request, response);

        } else if ("delete".equals(action)) {
            Long id = Long.parseLong(request.getParameter("id"));
            System.out.print(id);
            QueueEntry entry = queueFacade.findByQueueNumber(id);
            if (entry != null) {
                queueFacade.remove(entry);
            }
            response.sendRedirect("QueueMonitoringServlet.do");
        } else {
            List<QueueEntry> queueEntries = queueFacade.findAll();
            request.setAttribute("queueEntries", queueEntries);
            request.getRequestDispatcher("queue-monitoring.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.print("quueue mon do get ");

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            QueueEntry entry = extractFromRequest(request);
            entry.setRegistrationTime(new Date());
            queueFacade.save(entry);
        } else if ("update".equals(action)) {
            Long id = Long.parseLong(request.getParameter("id"));
            System.out.print(id);
            QueueEntry existing = queueFacade.findByQueueNumber(id);
            if (existing != null) {
                QueueEntry updated = extractFromRequest(request);
                existing.setQueueNumber(updated.getQueueNumber());
                existing.setPatient(updated.getPatient());
                existing.setStatus(updated.getStatus());
                existing.setPriority(updated.getPriority());
                existing.setNotes(updated.getNotes());
                queueFacade.update(existing);
            }
        }
        response.sendRedirect("QueueMonitoringServlet.do");
    }

    private QueueEntry extractFromRequest(HttpServletRequest request) {
        QueueEntry entry = new QueueEntry();
        entry.setQueueNumber(Integer.parseInt(request.getParameter("queueNumber")));
        Long patientId = Long.parseLong(request.getParameter("patientId"));
        Long doctorId = Long.parseLong(request.getParameter("doctorId"));
        entry.setPatient(patientFacade.findById(patientId));
        entry.setStatus(Status.valueOf(request.getParameter("status")));
        entry.setPriority(Priority.valueOf(request.getParameter("priority")));
        entry.setNotes(request.getParameter("notes"));
        return entry;
    }
}
