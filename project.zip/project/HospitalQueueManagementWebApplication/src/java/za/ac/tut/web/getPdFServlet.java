package za.ac.tut.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.DoctorFacadeLocal;
import za.ac.tut.entities.AccountStatus;
import za.ac.tut.entities.Doctor;

public class getPdFServlet extends HttpServlet {
    @EJB
    private DoctorFacadeLocal df;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<Doctor> doctors = df.findAll();

        // Count total doctors
        int totalDoctors = doctors.size();

        // Group doctors by status without streams or method references (Java 7 compatible)
        Map<AccountStatus, Long> statusCount = new HashMap<AccountStatus, Long>();
        for (Doctor doctor : doctors) {
            AccountStatus status = doctor.getStatus();
            Long count = statusCount.get(status);
            if (count == null) {
                statusCount.put(status, 1L);
            } else {
                statusCount.put(status, count + 1);
            }
        }

        // Put attributes for JSP
        request.setAttribute("totalDoctors", totalDoctors);
        request.setAttribute("statusCount", statusCount);
        request.setAttribute("doctors", doctors);

        // Forward to JSP report page
        RequestDispatcher disp = request.getRequestDispatcher("summaryPage.jsp");
        disp.forward(request, response);
    }
}
