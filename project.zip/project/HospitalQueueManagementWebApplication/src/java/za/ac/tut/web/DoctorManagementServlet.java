package za.ac.tut.web;

import za.ac.tut.entities.Doctor;
import za.ac.tut.ejb.bl.DoctorFacadeLocal;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class DoctorManagementServlet extends HttpServlet {

    @EJB
    private DoctorFacadeLocal doctorFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String path = request.getServletPath();

        String action = request.getParameter("action");

        if ("edit".equals(action)) {
            try {
                Long id = Long.parseLong(request.getParameter("id"));
                Doctor doctor = doctorFacade.findById(id);
                if (doctor != null) {
                    request.setAttribute("doctor", doctor);
                    request.getRequestDispatcher("/edit-doctor.jsp").forward(request, response);
                } else {
                    response.sendRedirect(request.getContextPath() + "/DoctorManagementServlet.do");
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/DoctorManagementServlet.do");
            }
        } else if (path.equals(
                "/delete-doctor.jsp")) {
            try {
                Long id = Long.parseLong(request.getParameter("id"));
                Doctor doctor = doctorFacade.findById(id);
                if (doctor != null) {
                    doctorFacade.remove(doctor);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            response.sendRedirect(request.getContextPath() + "/DoctorManagementServlet.do");

        } else {
            // Default: show doctor form + list
            List<Doctor> doctors = doctorFacade.findAll();
            request.setAttribute("doctors", doctors);
            request.getRequestDispatcher("/doctor-management.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            Doctor doctor = extractDoctorFromRequest(request);

            if (!isValidContact(doctor.getContactNumber())) {
                request.setAttribute("contactError", "Contact number must be exactly 10 digits.");
                List<Doctor> doctors = doctorFacade.findAll();
                request.setAttribute("doctors", doctors);
                request.getRequestDispatcher("/doctor-management.jsp").forward(request, response);
                return;
            }

            doctorFacade.save(doctor);
            response.sendRedirect(request.getContextPath() + "/DoctorManagementServlet.do");

        } else if ("update".equals(action)) {
            try {
                Long id = Long.parseLong(request.getParameter("id"));
                Doctor existingDoctor = doctorFacade.findById(id);

                if (existingDoctor != null) {
                    String newContact = request.getParameter("contactNumber");
                    if (!isValidContact(newContact)) {
                        request.setAttribute("contactError", "Contact number must be exactly 10 digits.");
                        request.setAttribute("doctor", existingDoctor);
                        request.getRequestDispatcher("/doctor-edit.jsp").forward(request, response);
                        return;
                    }

                    existingDoctor.setContactNumber(newContact);
                    String newPassword = request.getParameter("password");
                    if (newPassword != null && !newPassword.isEmpty()) {
                        existingDoctor.setPassword(newPassword);
                    }

                    doctorFacade.edit(existingDoctor);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            response.sendRedirect(request.getContextPath() + "/DoctorManagementServlet.do");
        }
    }

    private Doctor extractDoctorFromRequest(HttpServletRequest request) {
        Doctor doctor = new Doctor();
        doctor.setFirstName(request.getParameter("firstName"));
        doctor.setLastName(request.getParameter("lastName"));
        doctor.setSpecialization(request.getParameter("specialization"));
        doctor.setContactNumber(request.getParameter("contactNumber"));
        doctor.setEmail(request.getParameter("email"));
        doctor.setUsername(request.getParameter("username"));
        doctor.setPassword(request.getParameter("password"));
        return doctor;
    }

    private boolean isValidContact(String contact) {
        return contact != null && contact.matches("\\d{10}");
    }
}
