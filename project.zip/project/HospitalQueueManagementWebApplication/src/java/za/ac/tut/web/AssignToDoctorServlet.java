package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.DoctorFacadeLocal;
import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.Patient;
import za.ac.tut.entities.QueueEntry;

@WebServlet(name = "AssignToDoctorServlet", urlPatterns = {"/AssignToDoctorServlet.do"})
public class AssignToDoctorServlet extends HttpServlet {

    @EJB
    private PatientFacadeLocal patientFacade;

    @EJB
    private DoctorFacadeLocal doctorFacade;

    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String patientIdStr = request.getParameter("patientId");

        if (patientIdStr == null) {
            request.setAttribute("error", "No patient ID provided.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }

        try {
            Long patientId = Long.parseLong(patientIdStr);
            Patient patient = patientFacade.findById(patientId);

            if (patient == null) {
                request.setAttribute("error", "Patient not found.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }

            List<Doctor> doctors = doctorFacade.findAll();
            request.setAttribute("patient", patient);
            request.setAttribute("doctors", doctors);
            request.getRequestDispatcher("assignToDoctor.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid patient ID.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Long patientId = Long.parseLong(request.getParameter("patientId"));
            Long doctorId = Long.parseLong(request.getParameter("doctorId"));
            String priorityStr = request.getParameter("priority");
            String notes = request.getParameter("notes");

            Patient patient = patientFacade.findById(patientId);
            Doctor doctor = doctorFacade.findById(doctorId);

            if (patient == null || doctor == null) {
                request.setAttribute("error", "Patient or Doctor not found.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }

            // Increment assigned patients count for the doctor
            int currentAssignedPatients = doctor.getAssignedPatients();
            doctor.setAssignedPatients(currentAssignedPatients + 1);
            doctorFacade.edit(doctor); // Save the updated doctor

            // Create a new queue entry
            QueueEntry queueEntry = new QueueEntry();
            queueEntry.setPatient(patient);
            queueEntry.setAssignedDoctor(doctor);
            queueEntry.setPriority(QueueEntry.Priority.valueOf(priorityStr));
            queueEntry.setStatus(QueueEntry.Status.WAITING);
            queueEntry.setNotes(notes);
            queueEntry.setRegistrationTime(new Date());

            // Get the next queue number for the doctor
            int queueNumber = queueEntryFacade.getNextQueueNumberForDoctor(doctorId);
            queueEntry.setQueueNumber(queueNumber);

            // Save the queue entry
            queueEntryFacade.save(queueEntry);

            // Notify the clerk (redirect to confirmation page)
            request.setAttribute("message", "Patient has been successfully assigned to Dr. " + doctor.getLastName());
            request.getRequestDispatcher("assignmentSuccess.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error assigning patient to doctor.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Assigns a patient to a doctor and updates the assigned patients count.";
    }
}
