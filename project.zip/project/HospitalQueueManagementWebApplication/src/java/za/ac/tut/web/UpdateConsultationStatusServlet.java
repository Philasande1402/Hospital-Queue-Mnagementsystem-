package za.ac.tut.web;

import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.QueueEntry;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;


public class UpdateConsultationStatusServlet extends HttpServlet {

    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String queueEntryIdParam = request.getParameter("queueEntryId");
        String newStatusParam = request.getParameter("status");

        if (queueEntryIdParam == null || newStatusParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameters.");
            return;
        }

        try {
            Long queueEntryId = Long.parseLong(queueEntryIdParam);
            QueueEntry.Status newStatus = QueueEntry.Status.valueOf(newStatusParam);

            // Update the status
            queueEntryFacade.updateStatus(queueEntryId, newStatus);

            // Redirect back to dashboard or consultation detail page
            response.sendRedirect("DashboardServlet.do");

        } catch (IllegalArgumentException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters.");
        }
    }
}
