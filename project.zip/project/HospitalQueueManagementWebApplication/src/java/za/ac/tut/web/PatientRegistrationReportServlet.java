/*
 * Servlet: PatientRegistrationReportServlet
 * Created on: 07 May 2025, 6:45 PM
 * Author: HP
 */

package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.entities.Patient;

public class PatientRegistrationReportServlet extends HttpServlet {

    @EJB
    private PatientFacadeLocal cfl;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get the date parameters from the request
        String fromDateStr = request.getParameter("fromDate");
        String toDateStr = request.getParameter("toDate");
        String export = request.getParameter("export");

        // Define the expected date format
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        try {
            // Parse the input dates
            Date fromDate = format.parse(fromDateStr);
            Date toDate = format.parse(toDateStr);


            // Get patient data from database
            List<Patient> report = cfl.findPatientsWithinDateRange(fromDate, toDate);
            Long cnt = cfl.countPatients();
            /*Long numMales = cfl.cntAllMalePatients();
            Long numFemales = cfl.cntAllFemalePatients();*/

            // Set the retrieved data as request attributes
            request.setAttribute("report", report);
            request.setAttribute("fromDate", fromDate);
            request.setAttribute("toDate", toDate);
            /*request.setAttribute("numMales", numMales);
            request.setAttribute("numFemales", numFemales);*/
            request.setAttribute("cnt", cnt);

            // Forward to the JSP page to display results
            RequestDispatcher dispatcher = request.getRequestDispatcher("patientRegistrationReport.jsp");
            dispatcher.forward(request, response);

        } catch (ParseException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid date format.");
        }
    }

 

    @Override
    public String getServletInfo() {
        return "Handles patient registration report generation and export.";
    }
}
