import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class DeleteMedicalRecordServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the recordId from the form submission
        String recordId = request.getParameter("recordId");
        
        // Database connection setup
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        
        try {
            // Establish connection to the database
            String dbURL = "jdbc:mysql://localhost:3306/hospital_db";
            String dbUser = "root";
            String dbPassword = "password"; // Update with actual DB password
            
            connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
            
            // SQL query to delete the medical record
            String deleteQuery = "DELETE FROM medical_history WHERE id = ?";
            
            // Create PreparedStatement
            preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setString(1, recordId);
            
            // Execute the delete query
            int result = preparedStatement.executeUpdate();
            
            // Redirect back to the consultation page after deletion
            if (result > 0) {
                response.sendRedirect(request.getContextPath() + "/consultation.jsp?deleteSuccess=true");
            } else {
                response.sendRedirect(request.getContextPath() + "/consultation.jsp?deleteError=true");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/consultation.jsp?deleteError=true");
        } finally {
            // Close resources
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
