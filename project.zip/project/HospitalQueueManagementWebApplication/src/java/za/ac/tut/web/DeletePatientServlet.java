package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.entities.Patient;


public class DeletePatientServlet extends HttpServlet {

    @EJB
    private PatientFacadeLocal patientFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            Long patientId = Long.parseLong(request.getParameter("id"));

            Patient patient = patientFacade.findById(patientId);
            if (patient != null) {
                patientFacade.remove(patient);
            }

            // Redirect back to list after deletion
            response.sendRedirect("ViewPatientsServlet.do");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error deleting patient.");
        }
    }
}
