package za.ac.tut.web;

import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.QueueEntry;
import za.ac.tut.entities.UserType;

@WebServlet(name = "DashboardServlet", urlPatterns = {"/DashboardServlet.do"})
public class DashboardServlet extends HttpServlet {

    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("currentUser") == null
                || session.getAttribute("userType") != UserType.DOCTOR) {
            response.sendRedirect("login.jsp");
            return;
        }

        Doctor doctor = (Doctor) session.getAttribute("currentUser");
        List<QueueEntry> patientQueue = queueEntryFacade.getQueueForDoctor(doctor.getId());

        request.setAttribute("patientQueue", patientQueue);
        request.getRequestDispatcher("dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
