package za.ac.tut.web;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.QueueEntry;
import java.text.SimpleDateFormat;
import za.ac.tut.ejb.bl.DoctorFacadeLocal;

@WebServlet(name = "DoctorReportServlet", urlPatterns = {"/DoctorReport"})
public class DoctorReportServlet extends HttpServlet {
    
    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;
    
    @EJB
    private DoctorFacadeLocal doctorFacade;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Get the logged-in user
            Doctor loggedInDoctor = (Doctor) request.getSession().getAttribute("currentUser");
            if (loggedInDoctor == null) {
                request.setAttribute("error", "User is not logged in.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }
            
            // Set default date (beginning of the current month)
            Date currentDate = new Date();
            
            // Pass the actual Date object to the facade method, not a String
            List<QueueEntry> reports = queueEntryFacade.getReportsByDoctorAndDate(
                    loggedInDoctor.getId(), currentDate);
            
            // Format date for display in the JSP
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String startDateStr = sdf.format(currentDate);
            
            request.setAttribute("startDate", startDateStr);
            request.setAttribute("reports", reports);
            request.getRequestDispatcher("doctorReport.jsp").forward(request, response);
            
        } catch (Exception e) {
            System.err.println("Error in DoctorReportServlet doGet: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "An unexpected error occurred: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String startDateStr = request.getParameter("startDate");
            String endDateStr = request.getParameter("endDate");
            
            // Get the logged-in doctor
            Doctor loggedInDoctor = (Doctor) request.getSession().getAttribute("currentUser"); // Changed from loggedInDoctor
            if (loggedInDoctor == null) {
                request.setAttribute("error", "User is not logged in.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }
            
            // Convert String to Date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date startDate = null;
            Date endDate = null;
            
            try {
                startDate = sdf.parse(startDateStr);  // Parse startDate string to Date
                endDate = sdf.parse(endDateStr);      // Parse endDate string to Date
            } catch (ParseException e) {
                request.setAttribute("error", "Invalid date format. Please use YYYY-MM-DD format.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }
            
            // Fetch reports for the logged-in doctor
            List<QueueEntry> reports = queueEntryFacade.getReportsByDoctorAndDateRange(
                    loggedInDoctor.getId(), startDate, endDate);
            
            request.setAttribute("reports", reports);
            request.setAttribute("startDate", startDateStr); // Keep the selected dates in the form
            request.setAttribute("endDate", endDateStr);
            request.getRequestDispatcher("doctorReport.jsp").forward(request, response);
            
        } catch (Exception e) {
            System.err.println("Error in DoctorReportServlet doPost: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "An unexpected error occurred: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}