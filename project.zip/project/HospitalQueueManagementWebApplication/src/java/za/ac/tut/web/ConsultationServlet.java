// In ConsultationServlet.java
package za.ac.tut.web;

import za.ac.tut.ejb.bl.MedicalRecordFacadeLocal;
import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.entities.MedicalRecord;
import za.ac.tut.entities.Patient;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import za.ac.tut.ejb.bl.DoctorFacadeLocal;
import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.QueueEntry;

public class ConsultationServlet extends HttpServlet {

    @EJB
    private MedicalRecordFacadeLocal medicalRecordFacade;

    @EJB
    private PatientFacadeLocal patientFacade;

    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;

    @EJB
    private DoctorFacadeLocal doctorFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Entering consultation servlet doGet");

        String patientIdParam = request.getParameter("patientId");

        System.out.print(patientIdParam + " in consultation servlet");

        if (patientIdParam == null || patientIdParam.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Patient ID is required.");
            return;
        }

        try {
            Long patientId = Long.parseLong(patientIdParam);
            Patient patient = patientFacade.findById(patientId);

            if (patient == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Patient not found.");
                return;
            }

            // Try to get an existing MedicalRecord or create a new one
            MedicalRecord medicalRecord = medicalRecordFacade.findById(patientId);
            if (medicalRecord == null) {
                medicalRecord = new MedicalRecord();
                medicalRecord.setPatient(patient);
                medicalRecordFacade.save(medicalRecord); // Persist the new record
            }

            request.setAttribute("patient", patient);
            request.setAttribute("medicalRecord", medicalRecord);
            request.getRequestDispatcher("/consultation.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid Patient ID format.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Validate patientId and doctorId parameters first
            String patientIdParam = request.getParameter("patientId");
            String doctorIdParam = request.getParameter("doctorId");

            if (patientIdParam == null || patientIdParam.isEmpty()) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Patient ID is required.");
                return;
            }
            if (doctorIdParam == null || doctorIdParam.isEmpty()) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Doctor ID is required.");
                return;
            }

            Long patientId = Long.valueOf(patientIdParam);
            Long doctorId = Long.valueOf(doctorIdParam);

            Patient patient = patientFacade.findById(patientId);
            Doctor doctor = doctorFacade.findById(doctorId);

            if (patient == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Patient not found.");
                return;
            }
            if (doctor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Doctor not found.");
                return;
            }

            // Parse other parameters (with minimal validation here - you can add more if needed)
            String diagnosis = request.getParameter("diagnosis");
            String prescriptions = request.getParameter("prescriptions");
            String notes = request.getParameter("notes");

            Double temperature = request.getParameter("temperature") != null && !request.getParameter("temperature").isEmpty()
                    ? Double.valueOf(request.getParameter("temperature")) : null;
            String bloodPressure = request.getParameter("bloodPressure");
            Integer pulse = request.getParameter("pulse") != null && !request.getParameter("pulse").isEmpty()
                    ? Integer.valueOf(request.getParameter("pulse")) : null;
            Integer respiratoryRate = request.getParameter("respiratoryRate") != null && !request.getParameter("respiratoryRate").isEmpty()
                    ? Integer.valueOf(request.getParameter("respiratoryRate")) : null;
            Integer oxygenSaturation = request.getParameter("oxygenSaturation") != null && !request.getParameter("oxygenSaturation").isEmpty()
                    ? Integer.valueOf(request.getParameter("oxygenSaturation")) : null;

            // Create and populate MedicalRecord entity
            MedicalRecord medicalRecord = new MedicalRecord();
            medicalRecord.setPatient(patient);
            medicalRecord.setDoctor(doctor);
            medicalRecord.setDiagnosis(diagnosis);
            medicalRecord.setPrescriptions(prescriptions);
            medicalRecord.setNotes(notes);
            medicalRecord.setTemperature(temperature);
            medicalRecord.setBloodPressure(bloodPressure);
            medicalRecord.setPulse(pulse);
            medicalRecord.setRespiratoryRate(respiratoryRate);
            medicalRecord.setOxygenSaturation(oxygenSaturation);
            medicalRecord.setRecordDate(new Date());

            medicalRecordFacade.save(medicalRecord);

            // Update queue entry status if exists
            QueueEntry queueEntry = queueEntryFacade.findByPatientId(patientId);
            if (queueEntry != null) {
                queueEntry.setStatus(QueueEntry.Status.COMPLETED);
                queueEntryFacade.save(queueEntry);
            }

            // Get next waiting patient if available
            QueueEntry nextQueueEntry = queueEntryFacade.findNextWaitingPatient();
            Patient nextPatient = (nextQueueEntry != null) ? nextQueueEntry.getPatient() : null;

            if (nextPatient != null) {
                request.setAttribute("patient", patient); // current patient for success message
                request.setAttribute("nextPatient", nextPatient);
                request.setAttribute("nextQueueEntry", nextQueueEntry);
                request.getRequestDispatcher("/consultation-success.jsp").forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
            }

        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid number format in input.");
        }
    }

    private Patient getNextPatient() {
        QueueEntry nextEntry = queueEntryFacade.findNextWaitingPatient();
        return (nextEntry != null) ? nextEntry.getPatient() : null;
    }

}
