package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.util.List;
import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.ejb.bl.DoctorFacadeLocal;
import za.ac.tut.ejb.bl.ClerkFacadeLocal;
import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.Patient;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.Clerk;
import za.ac.tut.entities.QueueEntry;

public class SummaryReportServlet extends HttpServlet {

    @EJB
    private PatientFacadeLocal patientFacade;

    @EJB
    private DoctorFacadeLocal doctorFacade;

    @EJB
    private ClerkFacadeLocal clerkFacade;

    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Fetch key system metrics
        long totalPatients = patientFacade.countPatients();
        long totalDoctors = doctorFacade.count();
        long totalClerks = clerkFacade.count();
        long totalQueueEntries = queueEntryFacade.count();

        // Pending patients (unassigned to doctors)
        long pendingQueueEntries = queueEntryFacade.countWaitingEntries();

        // Get number of patients assigned to each doctor
        List<Doctor> doctors = doctorFacade.findAll();
        if (doctors != null) {
            for (Doctor doctor : doctors) {
                List<QueueEntry> doctorQueueEntries = queueEntryFacade.getQueueForDoctor(doctor.getId());
                doctor.setAssignedPatients(doctorQueueEntries.size()); // Assuming this method is available
            }
        }

        // Queue by priority (Normal, Urgent, Emergency)
        long normalPriorityCount = queueEntryFacade.countByPriority(QueueEntry.Priority.NORMAL);
        long urgentPriorityCount = queueEntryFacade.countByPriority(QueueEntry.Priority.URGENT);
        long emergencyPriorityCount = queueEntryFacade.countByPriority(QueueEntry.Priority.EMERGENCY);

        // Set the attributes to pass to the JSP page
        request.setAttribute("totalPatients", totalPatients);
        request.setAttribute("totalDoctors", totalDoctors);
        request.setAttribute("totalClerks", totalClerks);
        request.setAttribute("totalQueueEntries", totalQueueEntries);
        request.setAttribute("pendingQueueEntries", pendingQueueEntries);
        request.setAttribute("doctors", doctors); // List of doctors to display on the JSP
        request.setAttribute("normalPriorityCount", normalPriorityCount);
        request.setAttribute("urgentPriorityCount", urgentPriorityCount);
        request.setAttribute("emergencyPriorityCount", emergencyPriorityCount);

        // Forward to the JSP page to display the report
        request.getRequestDispatcher("summary-report.jsp").forward(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Generates a summary report for management to review key system metrics and statuses.";
    }
}
