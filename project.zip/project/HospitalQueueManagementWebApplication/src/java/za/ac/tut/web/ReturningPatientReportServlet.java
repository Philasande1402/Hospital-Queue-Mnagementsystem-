package za.ac.tut.web;

import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.entities.Patient;
import za.ac.tut.entities.Consultation;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

public class ReturningPatientReportServlet extends HttpServlet {

    @EJB
    private PatientFacadeLocal patientFacade;

   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Patient> allPatients = patientFacade.findAllPatients();
        request.setAttribute("patients", allPatients);
        request.getRequestDispatcher("/returningClerkReport.jsp").forward(request, response);
    }


}
