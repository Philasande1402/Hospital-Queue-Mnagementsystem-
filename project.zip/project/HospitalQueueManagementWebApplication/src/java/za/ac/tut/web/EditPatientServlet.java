package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.entities.Patient;

public class EditPatientServlet extends HttpServlet {

    @EJB
    private PatientFacadeLocal patientFacade;

    // Handle GET requests to display the patient details in the form
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get patient ID from the request parameter
        Long patientId = Long.parseLong(request.getParameter("id"));

        // Find the patient by ID
        Patient patient = patientFacade.findById(patientId);

        if (patient != null) {
            // If patient is found, set it as a request attribute and forward to the JSP
            request.setAttribute("patient", patient);
            request.getRequestDispatcher("/editPatient.jsp").forward(request, response);
        } else {
            // If patient is not found, send a 404 error
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Patient not found");
        }
    }

    // Handle POST requests to update the patient details
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the patient ID, email, and contact number from the form
        Long patientId = Long.parseLong(request.getParameter("id"));
        String contactNumber = request.getParameter("contactNumber");
        String email = request.getParameter("email");

        // Find the patient in the database by ID
        Patient patient = patientFacade.findById(patientId);

        if (patient != null) {
            // Update the contact number and email of the patient
            patient.setContactNumber(contactNumber);
            patient.setEmail(email);

            // Save the updated patient information
            patientFacade.edit(patient);

            // Redirect to the patient list page after successful update
            request.setAttribute("patient", patient);
            request.getRequestDispatcher("updatedPatient.jsp").forward(request, response);

        } else {
            // If patient is not found, send a 404 error
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Patient not found");
        }
    }
}
