 package za.ac.tut.web;

import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.QueueEntry;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class QueueReportServlet extends HttpServlet {

    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<QueueEntry> entries = queueEntryFacade.findAll();
        request.setAttribute("entries", entries);

        request.getRequestDispatcher("view_all_queue_entries.jsp").forward(request, response);
    }

    // Optional: Redirect POST requests to GET for simplicity
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}