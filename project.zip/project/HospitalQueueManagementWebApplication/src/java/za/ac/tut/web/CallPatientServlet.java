package za.ac.tut.web;

import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.QueueEntry;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class CallPatientServlet extends HttpServlet {

    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the queue entry ID from the request
        String queueEntryIdParam = request.getParameter("queueEntryId");
        
        System.out.println("entering call patient servlet");
        
        if (queueEntryIdParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Queue entry ID is required.");
            return;
        }

        try {
            // Parse the queue entry ID and find the QueueEntry
            Long queueEntryId = Long.parseLong(queueEntryIdParam);
            QueueEntry entry = queueEntryFacade.findById(queueEntryId);

            if (entry != null) {
                // Update the status to 'CALLED' using the updateStatus method
                queueEntryFacade.updateStatus(queueEntryId, QueueEntry.Status.IN_CONSULTATION);

                // Redirect to ConsultationServlet with the patient's ID
                Long patientId = entry.getPatient().getId(); // Get the patient's ID
                response.sendRedirect("ConsultationServlet.do?patientId=" + patientId); // Redirect to ConsultationServlet
                
                System.out.print(patientId);

            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Queue entry not found.");
            }
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid queue entry ID.");
        }
    }
}
