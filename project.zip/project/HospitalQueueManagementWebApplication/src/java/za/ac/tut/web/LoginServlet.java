package za.ac.tut.web;

import java.io.IOException;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import za.ac.tut.ejb.bl.AdministratorFacadeLocal;
import za.ac.tut.ejb.bl.ClerkFacadeLocal;
import za.ac.tut.ejb.bl.DoctorFacadeLocal;
import za.ac.tut.entities.Administrator;
import za.ac.tut.entities.Clerk;
import za.ac.tut.entities.Doctor;
import za.ac.tut.entities.UserType;
import za.ac.tut.entities.AccountStatus;

public class LoginServlet extends HttpServlet {

    @EJB
    private DoctorFacadeLocal doctorFacade;

    @EJB
    private ClerkFacadeLocal clerkFacade;

    @EJB
    private AdministratorFacadeLocal administratorFacade;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String userTypeParam = request.getParameter("userType");

        UserType userType;
        try {
            userType = UserType.valueOf(userTypeParam.toUpperCase());
        } catch (Exception e) {
            userType = UserType.DOCTOR; // Default fallback
        }

        HttpSession session = request.getSession(true);
        boolean loginSuccess = false;
        String redirectPage = "login.jsp";

        switch (userType) {
            case DOCTOR:
                Doctor doctor = doctorFacade.login(username, password);
                if (doctor != null && doctor.getStatus() == AccountStatus.ACTIVE) {
                    session.setAttribute("currentUser", doctor);
                    session.setAttribute("userType", UserType.DOCTOR);
                    redirectPage = "/DashboardServlet.do";
                    loginSuccess = true;
                } else if (doctor != null) {
                    request.setAttribute("error", "Doctor account is inactive.");
                }
                break;

            case CLERK:
                Clerk clerk = clerkFacade.login(username, password);
                if (clerk != null && clerk.getStatus() == AccountStatus.ACTIVE) {
                    clerk.setLastLogin(new Date());
                    clerkFacade.edit(clerk); // persist update

                    session.setAttribute("currentUser", clerk);
                    session.setAttribute("userType", UserType.CLERK);
                    redirectPage = "clerk-dashboard.jsp";
                    loginSuccess = true;
                    
                    System.out.println("clerk logged in");
                    System.out.println(userType);
                    System.out.println(clerk);
                } else if (clerk != null) {
                    request.setAttribute("error", "Clerk account is inactive.");
                }
                break;

            case ADMINISTRATOR:
                Administrator admin = administratorFacade.login(username, password);
                if (admin != null && admin.getStatus() == AccountStatus.ACTIVE) {
                    session.setAttribute("currentUser", admin);
                    session.setAttribute("userType", UserType.ADMINISTRATOR);
                    redirectPage = "/admin-dashboard.jsp";
                    loginSuccess = true;
                } else if (admin != null) {
                    request.setAttribute("error", "Administrator account is inactive.");
                }
                break;
        }

        if (loginSuccess) {
            RequestDispatcher dispatcher = request.getRequestDispatcher(redirectPage);
            dispatcher.forward(request, response);
        } else {
            if (request.getAttribute("error") == null) {
                request.setAttribute("error", "Invalid username or password");
            }
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "login.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Handles user login and redirects to the appropriate dashboard based on user type.";
    }
}
