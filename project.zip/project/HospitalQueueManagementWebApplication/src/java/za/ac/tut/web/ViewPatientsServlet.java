package za.ac.tut.web;

import za.ac.tut.ejb.bl.QueueEntryFacadeLocal;
import za.ac.tut.entities.QueueEntry;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;


public class ViewPatientsServlet extends HttpServlet {

    @EJB
    private QueueEntryFacadeLocal queueEntryFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String queueEntryIdParam = request.getParameter("queueEntryId");

        if (queueEntryIdParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Queue entry ID is required.");
            return;
        }

        try {
            Long queueEntryId = Long.parseLong(queueEntryIdParam);
            QueueEntry entry = queueEntryFacade.findById(queueEntryId);

            if (entry == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Queue entry not found.");
                return;
            }

            request.setAttribute("queueEntry", entry);
            request.getRequestDispatcher("consultationDetail.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid queue entry ID.");
        }
    }
}
