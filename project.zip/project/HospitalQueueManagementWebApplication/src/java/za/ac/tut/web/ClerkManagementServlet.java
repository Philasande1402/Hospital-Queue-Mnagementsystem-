package za.ac.tut.web;

import za.ac.tut.ejb.bl.ClerkFacadeLocal;
import za.ac.tut.entities.Clerk;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;
import za.ac.tut.entities.AccountStatus;

public class ClerkManagementServlet extends HttpServlet {

    @EJB
    private ClerkFacadeLocal clerkFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("edit".equals(action)) {
            Long id = Long.parseLong(request.getParameter("id"));
            Clerk clerk = clerkFacade.findById(id);
            request.setAttribute("clerk", clerk);
            request.getRequestDispatcher("/edit-clerk.jsp").forward(request, response);

        } else if ("delete".equals(action)) {
            Long id = Long.parseLong(request.getParameter("id"));
            Clerk clerk = clerkFacade.findById(id);
            if (clerk != null) {
                clerkFacade.remove(clerk);
            }
            List<Clerk> clerks = clerkFacade.findAll();
            request.setAttribute("clerks", clerks);
            request.getRequestDispatcher("/user-management.jsp").forward(request, response);
        } else {
            // Default: show all clerks
            List<Clerk> clerks = clerkFacade.findAll();
            request.setAttribute("clerks", clerks);
            request.getRequestDispatcher("/user-management.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            Clerk clerk = extractClerkFromRequest(request);
            clerkFacade.save(clerk);
            response.sendRedirect("ClerkManagementServlet.do");

        } else if ("update".equals(action)) {
            Long id = Long.parseLong(request.getParameter("clerkId"));
            Clerk existing = clerkFacade.findById(id);
            if (existing != null) {
                Clerk updated = extractClerkFromRequest(request);
                existing.setFullName(updated.getFullName());
                existing.setUsername(updated.getUsername());
                existing.setPassword(updated.getPassword());
                existing.setEmail(updated.getEmail());
                existing.setPhoneNumber(updated.getPhoneNumber());
                existing.setRole(updated.getRole());
                existing.setStatus(updated.getStatus());

                clerkFacade.update(existing);
            }
            response.sendRedirect("ClerkManagementServlet.do");
        }
    }

    private Clerk extractClerkFromRequest(HttpServletRequest request) {
        Clerk c = new Clerk();
        c.setFullName(request.getParameter("fullName"));
        c.setUsername(request.getParameter("username"));
        c.setPassword(request.getParameter("password"));
        c.setRole(request.getParameter("role"));
        c.setEmail(request.getParameter("email"));
        c.setPhoneNumber(request.getParameter("phoneNumber"));
        try {
            String statusParam = request.getParameter("status");
            AccountStatus status = AccountStatus.valueOf(statusParam.toUpperCase());
            c.setStatus(status);
        } catch (IllegalArgumentException | NullPointerException e) {
            // Optional: handle invalid status input
            request.setAttribute("error", "Invalid status value.");
        }
        return c;
    }
}
