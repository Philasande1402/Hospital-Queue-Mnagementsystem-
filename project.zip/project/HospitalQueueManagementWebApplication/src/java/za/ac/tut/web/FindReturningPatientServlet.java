package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import za.ac.tut.ejb.bl.PatientFacadeLocal;
import za.ac.tut.entities.Patient;

@WebServlet(name = "FindReturningPatientServlet", urlPatterns = {"/FindReturningPatientServlet"})
public class FindReturningPatientServlet extends HttpServlet {

    @EJB
    private PatientFacadeLocal patientFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            Long id = Long.parseLong(request.getParameter("id"));
            Patient patient = patientFacade.findById(id);

            if (patient != null) {
                request.setAttribute("patient", patient);
                request.getRequestDispatcher("returning_patient_details.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "No patient found with ID: " + id);
                request.getRequestDispatcher("returning_patient.jsp").forward(request, response);
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid patient ID format.");
            request.getRequestDispatcher("returning_patient.jsp").forward(request, response);
        }
    }
}
