package za.ac.tut.web;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.ClerkFacadeLocal;
import za.ac.tut.entities.Clerk;

/**
 * Servlet to generate Clerk reports.
 */
public class viewReportServlet extends HttpServlet {
    
    @EJB
    private ClerkFacadeLocal cfl;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Retrieve all clerks
        List<Clerk> clerks = cfl.findAll();
        
        // Count all clerks
        Integer countAll = clerks.size();
        
        // Count active clerks
        Integer countActive = 0;
        for (Clerk clerk : clerks) {
            if ("ACTIVE".equals(clerk.getStatus())) {
                countActive++;
            }
        }
        
        // Handle inactive clerks
        Integer countInactive = countAll - countActive;
        
        // Avoid division by zero for averageInactive calculation
        double averageInactive = (countInactive > 0) ? (double) countAll / countInactive : 0.0;
        
        // Handle active average calculation
        double averageActive = (countActive > 0) ? (double) countAll / countActive : 0.0;

        // Set the date to current date
        Date date = new Date();
        
        // Set attributes for JSP
        request.setAttribute("countAll", countAll);
        request.setAttribute("countActive", countActive);
        request.setAttribute("countInactive", countInactive);
        request.setAttribute("date", date);
        request.setAttribute("averageActive", averageActive);
        request.setAttribute("averageInactive", averageInactive);
        request.setAttribute("clerks", clerks);  // Add this line to set clerks attribute
        
        // Forward to the JSP page
        request.getRequestDispatcher("clerkReport.jsp").forward(request, response);
    }
}
